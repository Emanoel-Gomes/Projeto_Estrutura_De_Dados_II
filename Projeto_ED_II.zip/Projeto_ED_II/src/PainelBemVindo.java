import javax.swing.*;
import java.awt.*;

public class PainelBemVindo extends JFrame {
    public PainelBemVindo() {
        // Configurações básicas da janela
        setTitle("Painel de Boas-Vindas");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Painel principal
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Rótulo de boas-vindas
        JLabel label = new JLabel("<html><body><font size='5'>Bem-vindo, <span style='background-color: yellow;'>Felipe</span></font></body></html>");
        label.setHorizontalAlignment(JLabel.CENTER);
        
        // Adicionando o rótulo ao painel
        panel.add(label, BorderLayout.CENTER);

        // Adicionando o painel à janela
        add(panel);

        // Exibindo a janela
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PainelBemVindo());
    }
}
