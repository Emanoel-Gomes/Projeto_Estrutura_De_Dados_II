import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                PainelTexto painelTexto = new PainelTexto();
                PrefixTrie trie = new PrefixTrie();
    
                painelTexto.campoPesquisa.addKeyListener(new KeyAdapter() {
                    public void keyReleased(KeyEvent e) {
                        String prefixo = painelTexto.campoPesquisa.getText().toLowerCase();
                        List<String> sugestoes = PrefixTrie.sugerirPalavras(prefixo);
                        painelTexto.atualizarSugestoes(sugestoes);
                    }
                });
            }
        });
    }    
}
