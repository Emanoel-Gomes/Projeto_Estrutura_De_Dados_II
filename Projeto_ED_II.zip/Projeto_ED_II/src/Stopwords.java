import java.text.Normalizer;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Stopwords {
    static final Set<String> STOPWORDS = new HashSet<>(Arrays.asList(
            "a", "ao", "aos", "aquela", "aquelas", "aquele", "aqueles", "aquilo", "as", "ate",
            "com", "como", "da", "das", "de", "dela", "delas", "dele", "deles", "do", "dos",
            "e", "ela", "elas", "ele", "eles", "em", "entre", "era", "eram", "essa", "essas",
            "esse", "esses", "esta", "estas", "este", "estes", "eu", "fazendo", "foi", "foram",
            "ha", "isso", "isto", "ja", "lhe", "lhes", "mais", "na", "nao", "nas", "nem", "no",
            "nos", "nossa", "nossas", "nosso", "nossos", "o", "os", "ou", "para", "pela",
            "pelas", "pelo", "pelos", "por", "qual", "quando", "que", "quem", "se", "sem",
            "seu", "seus", "sob", "sobre", "sua", "suas", "tal", "tambem", "te", "tem", "tendo",
            "tenho", "ter", "teu", "teus", "tu", "tua", "tuas", "um", "uma", "umas", "uns",
            "voce", "voces", "vos", "seus", "suas"
    ));

    public static boolean isStopword(String word) {
        return STOPWORDS.contains(word.toLowerCase());
    }

    public static List<String> removeStopwords(List<String> words) {
        words.removeIf(Stopwords::isStopword);
        return words;
    }

    public static String removerAcentos(String palavra) {
        palavra = Normalizer.normalize(palavra, Normalizer.Form.NFD);
        palavra = palavra.replaceAll("\\p{M}", "");
        return palavra;
    }

    public static String removerNumeros(String palavra) {
        palavra = palavra.replaceAll("\\d", "");
        palavra = palavra.replaceAll("[^a-zA-Z0-9]", "");
        return palavra;
    }
}
