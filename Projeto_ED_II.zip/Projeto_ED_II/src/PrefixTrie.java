import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PrefixTrie {
    private static TrieNode root;

    public PrefixTrie() {
        root = new TrieNode();
    }

    public static void insert(String word) {
        TrieNode current = root;
        for (char c : word.toCharArray()) {
            if (!current.containsKey(c)) {
                current.put(c, new TrieNode());
            }
            current = current.get(c);
        }
        current.setEndOfWord(true);
    }

    public boolean search(String word) {
        TrieNode node = searchPrefix(word);
        return node != null && node.isEndOfWord();
    }

    public boolean startsWith(String prefix) {
        TrieNode node = searchPrefix(prefix);
        return node != null;
    }

    public static List<String> sugerirPalavras(String prefix) {
        List<String> sugestoes = new ArrayList<>();
        TrieNode node = searchPrefix(prefix);
        if (node != null) {
            sugestoes.addAll(collectWords(node, prefix));
        }
        return sugestoes;
    }
    

    private static TrieNode searchPrefix(String prefix) {
        TrieNode current = root;
        for (char c : prefix.toCharArray()) {
            if (current.containsKey(c)) {
                current = current.get(c);
            } else {
                return null;
            }
        }
        return current;
    }

    private static List<String> collectWords(TrieNode node, String prefix) {
        List<String> words = new ArrayList<>();
        if (node.isEndOfWord()) {
            words.add(prefix);
        }
        for (Map.Entry<Character, TrieNode> entry : node.getChildren().entrySet()) {
            char c = entry.getKey();
            TrieNode child = entry.getValue();
            String newPrefix = prefix + c;
            words.addAll(collectWords(child, newPrefix));
        }
        return words;
    }

    private static class TrieNode {
        private Map<Character, TrieNode> children;
        private boolean isEndOfWord;

        public TrieNode() {
            children = new HashMap<>();
            isEndOfWord = false;
        }

        public boolean containsKey(char c) {
            return children.containsKey(c);
        }

        public TrieNode get(char c) {
            return children.get(c);
        }

        public void put(char c, TrieNode node) {
            children.put(c, node);
        }

        public boolean isEndOfWord() {
            return isEndOfWord;
        }

        public void setEndOfWord(boolean endOfWord) {
            isEndOfWord = endOfWord;
        }

        public Map<Character, TrieNode> getChildren() {
            return children;
        }
    }
}
