import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Es_Arquivo {
    static String texto = "";

    public static List<String> sugerirPalavras(String prefix) {
        return PrefixTrie.sugerirPalavras(prefix);
    }

    public static void ler(String dir) throws IOException {
        try (BufferedReader lerBuff = new BufferedReader(new InputStreamReader(new FileInputStream(dir), "UTF-8"))) {
            String linha = "";
            while ((linha = lerBuff.readLine()) != null) {
                String[] palavras = linha.split(" ");
                for (String palavra : palavras) {
                    palavra = Stopwords.removerAcentos(palavra);
                    palavra = Stopwords.removerNumeros(palavra);
                    palavra = palavra.toLowerCase();
                    if (!palavra.isEmpty() && !Stopwords.isStopword(palavra) && !palavra.matches("[.,!?]")) {
                        PrefixTrie.insert(palavra);
                    }
                }
                texto += linha + "\n";
            }
        }

        // Adicionar o texto à árvore Trie
        PrefixTrie.insert(texto);
    }

    public static String buscarParagrafosComPalavra(String texto, String palavra) {
    String[] paragrafos = texto.split("\\.\\s"); // Divide o texto em parágrafos

    List<String> paragrafosEncontrados = new ArrayList<>();
    int contadorParagrafos = 0; // Contador de parágrafos
    int paragrafosPulados = 0; // Contador de parágrafos pulados
    int numeroParagrafoAnterior = 0; // Número do parágrafo anterior

    for (String paragrafo : paragrafos) {
        contadorParagrafos++; // Incrementa o contador de parágrafos

        if (paragrafo.contains(palavra)) {
            // Destaca a palavra com a cor vermelha usando códigos de escape ANSI
            String paragrafoFormatado = paragrafo.replace(palavra, "[" + palavra + "]");

            paragrafosEncontrados.add(paragrafoFormatado + " (Parágrafo " + contadorParagrafos + ")");

            if (numeroParagrafoAnterior != 0) {
                int paragrafosPuladosAtual = contadorParagrafos - numeroParagrafoAnterior;
                paragrafosPulados += paragrafosPuladosAtual;
                paragrafosEncontrados.add("Parágrafos pulados: " + paragrafosPuladosAtual);
            }

            numeroParagrafoAnterior = contadorParagrafos; // Atualiza o número do parágrafo anterior
        }
    }

    StringBuilder resultado = new StringBuilder();
    resultado.append("A palavra '").append(palavra).append("' foi encontrada em ").append(paragrafosEncontrados.size()).append(" parágrafo(s):\n\n");
    resultado.append(String.join("\n\n", paragrafosEncontrados));

    if (paragrafosEncontrados.isEmpty()) {
        resultado.insert(0, "Palavra não encontrada no texto.\n");
    } else {
        resultado.append("\n\n");
    }

    return resultado.toString();
}



    public static String ordenarTexto(String texto, String ordem) {
        String[] palavras = texto.split(" ");
        Map<String, Integer> map = new HashMap<>();

        for (String palavra : palavras) {
            String[] partes = palavra.split(":");
            String chave = partes[0];
            int valor = Integer.parseInt(partes[1]);
            map.put(chave, valor);
        }

        List<Map.Entry<String, Integer>> lista = new ArrayList<>(map.entrySet());

        switch (ordem) {
            case "ordemAlfabeticaD":
                Collections.sort(lista, (a, b) -> b.getKey().compareTo(a.getKey()));
                break;
            case "ordemAlfabeticaC":
                Collections.sort(lista, (a, b) -> a.getKey().compareTo(b.getKey()));
                break;
            case "ordemNumD":
                Collections.sort(lista, (a, b) -> b.getValue().compareTo(a.getValue()));
                break;
            case "ordemNumC":
                Collections.sort(lista, (a, b) -> a.getValue().compareTo(b.getValue()));
                break;
            default:
                throw new IllegalArgumentException("Ordem inválida: " + ordem);
        }

        StringBuilder resultado = new StringBuilder();
        for (Map.Entry<String, Integer> entry : lista) {
            resultado.append(entry.getKey()).append(":").append(entry.getValue()).append(" ");
        }

        return resultado.toString().trim();
    }

    public static String getTexto() {
        return texto;
    }
}
